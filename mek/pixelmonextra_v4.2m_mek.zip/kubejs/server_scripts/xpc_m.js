onEvent('recipes', event => {
  event.shaped('pixelmon:m_exp_candy', [
    'ABC',
    'DEF',
    'GHI'
  ], {
    A: 'minecraft:blue_ice',
    B: 'pixelmon:crystal',
    C: 'minecraft:blue_ice',
    D: 'minecraft:crying_obsidian',
    E: 'pixelmon:s_exp_candy',
    F: 'minecraft:crying_obsidian',
    G: 'minecraft:blue_ice',
    H: 'pixelmon:crystal',
    I: 'minecraft:blue_ice'
  });
});
