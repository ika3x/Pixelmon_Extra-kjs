onEvent('recipes', event => {
    event.recipes.mekanismInjecting('4x mekanism:dirty_netherite_scrap', 'minecraft:ancient_debris', {gas: 'mekanism:hydrogen_chloride', amount: 1})
    });