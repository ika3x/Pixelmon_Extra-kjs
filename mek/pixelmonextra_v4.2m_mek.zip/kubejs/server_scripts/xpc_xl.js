onEvent('recipes', event => {
  event.shaped('pixelmon:xl_exp_candy', [
    'ABC',
    'DEF',
    'GHI'
  ], {
    A: 'minecraft:nether_star',
    B: 'minecraft:command_block',
    C: 'minecraft:nether_star',
    D: 'pixelmon:crystal_block',
    E: 'pixelmon:l_exp_candy',
    F: 'pixelmon:crystal_block',
    G: 'minecraft:nether_star',
    H: 'minecraft:blue_ice',
    I: 'minecraft:nether_star'
  });
});
