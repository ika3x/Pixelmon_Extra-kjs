onEvent('recipes', event => {
 event.shapeless('4x kubejs:dust_al', [
    'pixelmon:bauxite_ore',
    'kubejs:apricore1'
  ]);
   event.shapeless('4x kubejs:dust_ag', [
    'pixelmon:silver_ore',
    'kubejs:apricore1'
  ]);
 event.shapeless('4x kubejs:dust_pt', [
    'pixelmon:platinum_ore',
    'kubejs:apricore1'
  ]);
  event.shapeless('4x kubejs:dust_si', [
    'pixelmon:silicon_ore',
    'kubejs:apricore1'
  ]);
  event.shapeless('4x kubejs:dust_al2o3_red', [
    'pixelmon:ruby_ore',
    'kubejs:apricore1'
  ]);
  event.shapeless('4x kubejs:dust_al2o3_blue', [
    'pixelmon:sapphire_ore',
    'kubejs:apricore1'
  ]);
  event.shapeless('4x kubejs:dust_sio2_purple', [
    'pixelmon:amethyst_ore',
    'kubejs:apricore1'
  ]);
  event.shapeless('4x kubejs:dust_sio2_white', [
    'pixelmon:crystal_ore',
    'kubejs:apricore1'
  ]);
  event.shapeless('7x kubejs:dust_al', [
  'pixelmon:bauxite_ore',
  'kubejs:apricore2'
]);
event.shapeless('7x kubejs:dust_ag', [
  'pixelmon:silver_ore',
  'kubejs:apricore2'
]);
event.shapeless('7x kubejs:dust_pt', [
  'pixelmon:platinum_ore',
  'kubejs:apricore2'
]);
event.shapeless('7x kubejs:dust_si', [
  'pixelmon:silicon_ore',
  'kubejs:apricore2'
]);
event.shapeless('7x kubejs:dust_al2o3_red', [
  'pixelmon:ruby_ore',
  'kubejs:apricore2'
]);
event.shapeless('7x kubejs:dust_al2o3_blue', [
  'pixelmon:sapphire_ore',
  'kubejs:apricore2'
]);
event.shapeless('7x kubejs:dust_sio2_purple', [
  'pixelmon:amethyst_ore',
  'kubejs:apricore2'
]);
event.shapeless('7x kubejs:dust_sio2_white', [
  'pixelmon:crystal_ore',
  'kubejs:apricore2'
]);
// (12, 3)
event.shapeless('12x kubejs:dust_al', [
  'pixelmon:bauxite_ore',
  'kubejs:apricore3'
]);
event.shapeless('12x kubejs:dust_ag', [
  'pixelmon:silver_ore',
  'kubejs:apricore3'
]);
event.shapeless('12x kubejs:dust_pt', [
  'pixelmon:platinum_ore',
  'kubejs:apricore3'
]);
event.shapeless('12x kubejs:dust_si', [
  'pixelmon:silicon_ore',
  'kubejs:apricore3'
]);
event.shapeless('12x kubejs:dust_al2o3_red', [
  'pixelmon:ruby_ore',
  'kubejs:apricore3'
]);
event.shapeless('12x kubejs:dust_al2o3_blue', [
  'pixelmon:sapphire_ore',
  'kubejs:apricore3'
]);
event.shapeless('12x kubejs:dust_sio2_purple', [
  'pixelmon:amethyst_ore',
  'kubejs:apricore3'
]);
event.shapeless('12x kubejs:dust_sio2_white', [
  'pixelmon:crystal_ore',
  'kubejs:apricore3'
]);

// (32, 4)
event.shapeless('32x kubejs:dust_al', [
  'pixelmon:bauxite_ore',
  'kubejs:apricore4'
]);
event.shapeless('32x kubejs:dust_ag', [
  'pixelmon:silver_ore',
  'kubejs:apricore4'
]);
event.shapeless('32x kubejs:dust_pt', [
  'pixelmon:platinum_ore',
  'kubejs:apricore4'
]);
event.shapeless('32x kubejs:dust_si', [
  'pixelmon:silicon_ore',
  'kubejs:apricore4'
]);
event.shapeless('32x kubejs:dust_al2o3_red', [
  'pixelmon:ruby_ore',
  'kubejs:apricore4'
]);
event.shapeless('32x kubejs:dust_al2o3_blue', [
  'pixelmon:sapphire_ore',
  'kubejs:apricore4'
]);
event.shapeless('32x kubejs:dust_sio2_purple', [
  'pixelmon:amethyst_ore',
  'kubejs:apricore4'
]);
event.shapeless('32x kubejs:dust_sio2_white', [
  'pixelmon:crystal_ore',
  'kubejs:apricore4'
]);

// (144, 5)
event.shapeless('16x pixelmon:aluminium_block', [
  'pixelmon:bauxite_ore',
  'kubejs:apricore5'
]);
event.shapeless('16x pixelmon:silver_block', [
  'pixelmon:silver_ore',
  'kubejs:apricore5'
]);
event.shapeless('16x pixelmon:platinum_block', [
  'pixelmon:platinum_ore',
  'kubejs:apricore5'
]);
event.shapeless('16x pixelmon:silicon_block', [
  'pixelmon:silicon_ore',
  'kubejs:apricore5'
]);
event.shapeless('16x pixelmon:ruby_block', [
  'pixelmon:ruby_ore',
  'kubejs:apricore5'
]);
event.shapeless('16x pixelmon:sapphire_block', [
  'pixelmon:sapphire_ore',
  'kubejs:apricore5'
]);
event.shapeless('16x pixelmon:amethyst_block', [
  'pixelmon:amethyst_ore',
  'kubejs:apricore5'
]);
event.shapeless('16x pixelmon:crystal_block', [
  'pixelmon:crystal_ore',
  'kubejs:apricore5'
]);

// (576, 6)
event.shapeless('64x pixelmon:aluminium_block', [
  'pixelmon:bauxite_ore',
  'kubejs:apricore6'
]);
event.shapeless('64x pixelmon:silver_block', [
  'pixelmon:silver_ore',
  'kubejs:apricore6'
]);
event.shapeless('64x pixelmon:platinum_block', [
  'pixelmon:platinum_ore',
  'kubejs:apricore6'
]);
event.shapeless('64x pixelmon:silicon_block', [
  'pixelmon:silicon_ore',
  'kubejs:apricore6'
]);
event.shapeless('64x pixelmon:ruby_block', [
  'pixelmon:ruby_ore',
  'kubejs:apricore6'
]);
event.shapeless('64x pixelmon:sapphire_block', [
  'pixelmon:sapphire_ore',
  'kubejs:apricore6'
]);
event.shapeless('64x pixelmon:amethyst_block', [
  'pixelmon:amethyst_ore',
  'kubejs:apricore6'
]);
event.shapeless('64x pixelmon:crystal_block', [
  'pixelmon:crystal_ore',
  'kubejs:apricore6'
]);
});