onEvent('recipes', event => {
  event.shaped('pixelmon:xs_exp_candy', [
    'ABC',
    'DEF',
    'GHI'
  ], {
    A: 'minecraft:sugar',
    B: 'minecraft:sugar',
    C: 'minecraft:sugar',
    D: 'minecraft:sugar',
    E: 'minecraft:blue_ice',
    F: 'minecraft:sugar',
    G: 'minecraft:sugar',
    H: 'minecraft:sugar',
    I: 'minecraft:sugar'
  });
});
