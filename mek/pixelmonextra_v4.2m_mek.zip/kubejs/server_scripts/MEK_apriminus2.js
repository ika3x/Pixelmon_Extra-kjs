onEvent('recipes', event => {
event.recipes.mekanismCrushing('8x kubejs:apricore0', 'kubejs:apricore1')
event.recipes.mekanismCrushing('8x kubejs:apricore1', 'kubejs:apricore2')
event.recipes.mekanismCrushing('8x kubejs:apricore2', 'kubejs:apricore3')
event.recipes.mekanismCrushing('7x kubejs:apricore3', 'kubejs:apricore4')
event.recipes.mekanismCrushing('7x kubejs:apricore4', 'kubejs:apricore5')
event.recipes.mekanismCrushing('6x kubejs:apricore5', 'kubejs:apricore6')
});