onEvent('item.registry', event => {
  // Apricores
  event.create('apricore0').displayName('Aprinium').texture('kubejs:item/apricore0');
  event.create('apricore1').displayName('§bAprishard').texture('kubejs:item/apricore1');
  event.create('apricore2').displayName('§bApricrystal').texture('kubejs:item/apricore2');
  event.create('apricore3').displayName('§dApristar').texture('kubejs:item/apricore3');
  event.create('apricore4').displayName('§dAprivoid').texture('kubejs:item/apricore4');
  event.create('apricore5').displayName('§5Aprinull').texture('kubejs:item/apricore5');
  event.create('apricore6').displayName('§cA§6p§er§ai§bc§9o§5r§de').texture('kubejs:item/apricore6');
});