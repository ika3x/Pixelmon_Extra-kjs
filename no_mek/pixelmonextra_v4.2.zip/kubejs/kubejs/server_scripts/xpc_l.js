onEvent('recipes', event => {
  event.shaped('pixelmon:l_exp_candy', [
    'ABC',
    'DEF',
    'GHI'
  ], {
    A: 'pixelmon:platinum_block',
    B: 'minecraft:nether_star',
    C: 'pixelmon:platinum_block',
    D: 'pixelmon:crystal_block',
    E: 'pixelmon:m_exp_candy',
    F: 'pixelmon:crystal_block',
    G: 'minecraft:blue_ice',
    H: 'minecraft:crying_obsidian',
    I: 'minecraft:blue_ice'
  });
});
