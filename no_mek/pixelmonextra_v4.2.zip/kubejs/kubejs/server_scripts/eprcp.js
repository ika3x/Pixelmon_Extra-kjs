onEvent('recipes', event => {
  event.shaped('minecraft:ender_pearl', [
    'AAA',
    'AIA',
    'AAA'
  ], {
    A: 'minecraft:green_stained_glass_pane',
    I: 'minecraft:chorus_fruit'
  });
});
