onEvent('recipes', event => {
  event.shaped('2x minecraft:ender_eye', [
    'GGG',
    'E B',
    'YYY'
  ], {
    B: 'minecraft:blaze_powder',
    E: 'minecraft:ender_pearl',
    G: 'minecraft:green_stained_glass_pane',
    Y: 'minecraft:yellow_stained_glass_pane'
  });
});
